package com.poise.Poise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoiseApplication.class, args);
	}

}
