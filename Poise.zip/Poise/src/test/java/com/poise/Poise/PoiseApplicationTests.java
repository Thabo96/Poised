package com.poise.Poise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
